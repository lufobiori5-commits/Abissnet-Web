{
    'name': 'GPS Tracking Fleet',
    'version': '1.0',
    'depends': ['fleet'],
    'category': 'Fleet',
    'author': 'ChatGPT',
    'data': [],
    'installable': True
}